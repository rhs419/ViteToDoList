<template>
    <tr v-for="(todo, key) in todos" v-bind=localStorage>
        <td><input type="checkbox" :id="'todoCheck'+todo.id" class="todoCheck" @click="toDoDone" :checked="completed"/></td>
        <td><label :id="'todoLabel'+todo.id">{{todo.todoText}}</label></td>
        <td><button type="button" :id="todo.id" class="delButton" @click="delToDoLS">삭제</button></td>
    </tr>
</template>

<script lang="ts">
import {toDoDone} from '../assets/script/todoList'
import {delToDoLS} from '../assets/script/todoList'
export default {
    name: "ToDoItem",
    methods: {
        toDoDone: toDoDone,
        delToDoLS: delToDoLS
    },
    props:{
        completed : Boolean
    },
    data:()=>({
        todos: Object.keys(localStorage).filter(key=>key!='number'&&JSON.parse(localStorage.getItem(key)!).checked===false)
                .map(key=>JSON.parse(localStorage.getItem(key)!))
                .sort(id=>id)
    })
}
</script>

<style scoped>

</style>