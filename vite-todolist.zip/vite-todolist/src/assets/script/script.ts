class test{
    static aa() {
        alert("aa");
    }
}